import type { VerificationData, NewsArticle } from '../types';

const NEWS_API_KEY = '3162c80174b048a39c2f66aa45f19863';

const TRUSTED_SOURCE_IDS = new Set([
  'reuters', 'bloomberg', 'cnbc', 'financial-times', 'the-wall-street-journal',
  'bbc-news', 'the-guardian-uk', 'the-associated-press', 'forbes', 'business-insider',
  'the-times-of-india', 'the-economic-times', 'business-standard', 'livemint',
  'ndtv-profit', 'financial-express', 'bloombergquint'
]);

const callNewsApi = async (url: string) => {
    // Switched to a different CORS proxy to resolve fetch errors. The previous one was unreliable.
    const proxyUrl = `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(url)}`;
    try {
        const proxyResponse = await fetch(proxyUrl);
        if (!proxyResponse.ok) {
            throw new Error(`News API request failed via proxy: ${proxyResponse.status} ${proxyResponse.statusText}`);
        }
        
        const data = await proxyResponse.json();

        if (data.status === 'error') {
            console.error('NewsAPI Error:', data.message);
        }
        return data;

    } catch (error) {
        console.error('Failed to fetch or process news via CORS proxy:', error);
        return { status: 'error', message: error instanceof Error ? error.message : 'Unknown fetch error' };
    }
}

export const fetchTopHeadlines = async (): Promise<NewsArticle[]> => {
    const headlinesUrl = `https://newsapi.org/v2/top-headlines?` + new URLSearchParams({
        category: 'business',
        language: 'en',
        country: 'us',
        pageSize: '12',
        apiKey: NEWS_API_KEY
    });

    const data = await callNewsApi(headlinesUrl);
    if (data.status === 'error') {
        return []; // Return empty array on error to prevent UI crash
    }
    return (data.articles || []).filter((article: NewsArticle) => article.title && (article.content || article.description));
}

export const fetchAndVerifyNews = async (query: string): Promise<VerificationData> => {
  if (!query) {
    return { credibility: 'Low', verifiedSources: [] };
  }

  const searchUrl = `https://newsapi.org/v2/everything?` +
    new URLSearchParams({
      q: query,
      apiKey: NEWS_API_KEY,
      language: 'en',
      sortBy: 'relevancy',
      pageSize: '20'
    });

  const data = await callNewsApi(searchUrl);
   if (data.status === 'error') {
       return { credibility: 'Low', verifiedSources: [] };
   }

  const articles = data.articles || [];
  const foundSources = new Set<string>();

  for (const article of articles) {
    const sourceId = article.source?.id;
    if (sourceId && TRUSTED_SOURCE_IDS.has(sourceId)) {
      foundSources.add(article.source.name);
    }
  }
  
  const verifiedSources = Array.from(foundSources);
  let credibility: 'High' | 'Medium' | 'Low';

  if (verifiedSources.length >= 3) {
    credibility = 'High';
  } else if (verifiedSources.length >= 1) {
    credibility = 'Medium';
  } else {
    credibility = 'Low';
  }

  return { credibility, verifiedSources };
};
