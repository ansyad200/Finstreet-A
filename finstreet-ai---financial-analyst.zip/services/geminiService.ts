import { GoogleGenAI } from "@google/genai";
import type { NewsAnalysis, QuarterlyComparison, Source } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const newsAnalysisPrompt = `
You are "Finstreet AI," a specialized financial news analyst. Your task is to analyze the provided financial news article and provide a structured analysis of its potential market impact.

**NEWS ARTICLE TEXT:**
---
{ARTICLE_CONTENT}
---

**YOUR TASK:**
1.  Determine the overall sentiment of the article (Positive, Negative, Neutral).
2.  Predict the potential impact on the company or market (High, Medium, Low, N/A).
3.  Provide a concise rationale for your analysis, referencing specific parts of the text.
4.  Use your search capabilities to find a historical precedent or related market data to ground your analysis.
5.  Provide a confidence score (0.0 to 1.0) for your prediction.

**RESPONSE FORMAT:**
You MUST respond with ONLY a valid JSON object. Do not include markdown formatting like \`\`\`json or any other text. The JSON object must conform to the following structure:
{
  "sentiment": "string ('Positive', 'Negative', 'Neutral')",
  "predictedImpact": "string ('High', 'Medium', 'Low', 'N/A')",
  "rationale": "string (A concise explanation for your analysis, including historical context found via search.)",
  "confidenceScore": "number (A float between 0.0 and 1.0)"
}
`;

const quarterlyAnalysisPrompt = `
You are "Finstreet AI," a world-class financial analyst AI. Your task is to provide a comprehensive, multi-faceted quarterly performance analysis for a specific company.

**ANALYSIS REQUEST:**
- Company: {COMPANY_NAME}
- Quarter: {QUARTER}
- Year: {YEAR}

**YOUR TASK:**
1.  Use your search capabilities to find the financial results for the company for the specified quarter and year (the "current period") and the same quarter of the *previous* year (the "previous period").
2.  Synthesize all findings into a detailed JSON object as specified below. The analysis must be deep and cover all requested sections.
3.  For the performance summary, include both Year-over-Year (YoY) and Quarter-over-Quarter (QoQ) context if available and significant.
4.  For the peer comparison, identify one primary competitor and compare at least two relevant metrics (e.g., P/E Ratio, Revenue Growth, EV/EBITDA).
5.  If data for a specific field (like segment performance or peer comparison) is not available, the field can be null.

**RESPONSE FORMAT:**
You MUST respond with ONLY a valid JSON object. Do not include markdown formatting like \`\`\`json or any other text. The JSON object must conform to the following structure:

{
  "companyName": "string (The full name of the company analyzed)",
  "currentPeriod": "string (e.g., 'Q2 2024')",
  "previousPeriod": "string (e.g., 'Q2 2023')",
  "performanceSummary": "string (A concise, high-level summary of the YoY performance, explaining key results, drivers, and mentioning significant QoQ changes.)",
  "comparisonMetrics": [
    { "metric": "Revenue", "currentValue": "string", "previousValue": "string", "changePercentage": "number | null" },
    { "metric": "EBITDA", "currentValue": "string", "previousValue": "string", "changePercentage": "number | null" },
    { "metric": "Net Profit (PAT)", "currentValue": "string", "previousValue": "string", "changePercentage": "number | null" },
    { "metric": "Earnings Per Share (EPS)", "currentValue": "string", "previousValue": "string", "changePercentage": "number | null" },
    { "metric": "Operating Margin", "currentValue": "string (e.g. '25.5%')", "previousValue": "string (e.g. '24.1%')", "changePercentage": "number | null" }
  ],
  "managementGuidance": "string (A summary of management's commentary, forward-looking guidance, and overall tone. If none was provided, state that.)",
  "balanceSheetHealth": {
    "summary": "string (A brief assessment of the balance sheet's strength, leverage, and liquidity.)",
    "metrics": [
      { "metric": "Total Debt", "value": "string" },
      { "metric": "Cash and Equivalents", "value": "string" },
      { "metric": "Operating Cash Flow", "value": "string" },
      { "metric": "Capital Expenditure (CapEx)", "value": "string" },
      { "metric": "Return on Equity (ROE)", "value": "string" }
    ]
  },
  "segmentPerformance": [
    {
      "segmentName": "string (e.g., 'iPhone', 'Cloud Services')",
      "revenue": "string (Revenue for the segment)",
      "commentary": "string (Brief summary of the segment's performance and key drivers)"
    }
  ],
  "risksAndOutlook": "string (Summarize key risks mentioned by management, including macroeconomic, competitive, or regulatory factors, and the overall outlook.)",
  "peerComparison": {
    "summary": "string (A brief summary comparing the company to its peer on the chosen metrics.)",
    "metrics": [
      { "metric": "string (e.g., 'P/E Ratio')", "companyValue": "string", "peerName": "string (Name of the competitor)", "peerValue": "string" },
      { "metric": "string (e.g., 'Revenue Growth YoY')", "companyValue": "string", "peerName": "string", "peerValue": "string" }
    ]
  }
}
`;

const parseJsonResponse = <T>(text: string): T => {
    let jsonText = text;
    
    // Look for a JSON markdown block anywhere in the text
    const markdownMatch = text.match(/```json\s*([\s\S]*?)\s*```/);
    if (markdownMatch && markdownMatch[1]) {
        jsonText = markdownMatch[1];
    } else {
        // Fallback for non-markdown-wrapped JSON that might be embedded in text.
        // Find the first '{' and last '}' to extract the JSON object.
        const firstBrace = text.indexOf('{');
        const lastBrace = text.lastIndexOf('}');
        if (firstBrace !== -1 && lastBrace > firstBrace) {
            jsonText = text.substring(firstBrace, lastBrace + 1);
        }
        // If it's an array, find the first '[' and last ']'
        else {
             const firstBracket = text.indexOf('[');
             const lastBracket = text.lastIndexOf(']');
             if (firstBracket !== -1 && lastBracket > firstBracket) {
                jsonText = text.substring(firstBracket, lastBracket + 1);
            }
        }
    }

    try {
        return JSON.parse(jsonText.trim());
    } catch (error) {
        console.error("Failed to parse JSON. Raw text from AI:", text);
        console.error("Attempted to parse:", jsonText);
        if (error instanceof SyntaxError) {
             throw new Error(`Failed to parse the AI's response. The format was invalid JSON.`);
        }
        throw error;
    }
};

export const analyzeFinancialNews = async (
    articleText: string
): Promise<{ result: NewsAnalysis; sources: Source[] }> => {
    try {
        if (!articleText || articleText.trim().length < 50) {
            throw new Error("Article content is too short to provide a meaningful analysis.");
        }
        
        const prompt = newsAnalysisPrompt.replace('{ARTICLE_CONTENT}', articleText);

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                tools: [{googleSearch: {}}],
                temperature: 0.2,
                topP: 0.8,
            },
        });

        if (!response.text) {
            throw new Error("Received an empty response from the AI.");
        }

        const result: NewsAnalysis = parseJsonResponse(response.text);
        const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];

        return { result, sources };

    } catch (error) {
        console.error("Error analyzing financial news:", error);
        throw error;
    }
};

export const analyzeQuarterlyPerformance = async (
    company: string, year: string, quarter: string
): Promise<{ result: QuarterlyComparison; sources: Source[] }> => {
  try {
    if (!company || !year || !quarter) {
        throw new Error("Company, year, and quarter must be provided for analysis.");
    }
    const yearNum = parseInt(year, 10);
    if (isNaN(yearNum)) {
        throw new Error("Year must be a valid number.");
    }

    let prompt = quarterlyAnalysisPrompt.replace('{COMPANY_NAME}', company);
    prompt = prompt.replace(/{QUARTER}/g, quarter);
    prompt = prompt.replace(/{YEAR}/g, year);
    prompt = prompt.replace('{YEAR - 1}', (yearNum - 1).toString());


    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{googleSearch: {}}],
        temperature: 0.1,
        topP: 0.8,
      },
    });

    if (!response.text) {
        throw new Error("Received an empty response from the AI.");
    }
    
    const result: QuarterlyComparison = parseJsonResponse(response.text);
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];

    return { result, sources };

  } catch (error)
 {
    console.error("Error analyzing quarterly performance:", error);
    throw error;
  }
};