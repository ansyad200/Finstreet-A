import React from 'react';
import type { QuarterlyComparison, QuarterlyComparisonMetric, Source, SimpleKeyValueMetric, PeerMetric, SegmentPerformance } from '../types';

interface QuarterlyComparisonDisplayProps {
  analysis: QuarterlyComparison;
  sources: Source[];
  onReset: () => void;
}

const InfoCard: React.FC<{ title: string; children: React.ReactNode, className?: string }> = ({ title, children, className = '' }) => (
  <div className={`bg-gray-800/50 border border-gray-700/60 rounded-lg shadow-lg p-6 h-full ${className}`}>
    <h3 className="text-sm font-semibold text-cyan-400 uppercase tracking-wider mb-3">{title}</h3>
    <div className="text-gray-300 space-y-3 leading-relaxed">{children}</div>
  </div>
);

const ChangeIndicator: React.FC<{ value: number | null | undefined }> = ({ value }) => {
    if (value === null || value === undefined || !isFinite(value)) {
        return <span className="text-gray-400 font-mono text-right">-</span>;
    }
    
    const isPositive = value >= 0;
    const colorClass = isPositive ? 'text-green-400' : 'text-red-400';
    const icon = isPositive ? (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
        </svg>
    ) : (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
    );

    return (
        <span className={`flex items-center justify-end font-mono ${colorClass}`}>
            {icon}
            {value.toFixed(2)}%
        </span>
    );
};


const ComparisonTable: React.FC<{ metrics: QuarterlyComparisonMetric[], currentPeriod: string, previousPeriod: string }> = ({ metrics, currentPeriod, previousPeriod }) => (
  <table className="w-full text-left">
    <thead>
      <tr className="border-b border-gray-600">
        <th className="py-2 text-xs font-medium text-gray-400">Metric</th>
        <th className="py-2 text-xs font-medium text-gray-400 text-right">{currentPeriod}</th>
        <th className="py-2 text-xs font-medium text-gray-400 text-right">{previousPeriod}</th>
        <th className="py-2 pl-4 text-xs font-medium text-gray-400 text-right">YoY Change</th>
      </tr>
    </thead>
    <tbody>
      {metrics.map((item, index) => (
        <tr key={index} className="border-b border-gray-700/50 last:border-b-0">
          <td className="py-3 font-semibold text-gray-200">{item.metric}</td>
          <td className="py-3 font-mono text-gray-200 text-right">{item.currentValue}</td>
          <td className="py-3 font-mono text-gray-400 text-right">{item.previousValue}</td>
          <td className="py-3 text-right pl-4">
            <ChangeIndicator value={item.changePercentage} />
          </td>
        </tr>
      ))}
    </tbody>
  </table>
);

const SimpleMetricsDisplay: React.FC<{ metrics: SimpleKeyValueMetric[] }> = ({ metrics }) => (
    <div className="space-y-2">
        {metrics.map((item, index) => (
            <div key={index} className="flex justify-between items-center text-sm border-b border-gray-700/50 pb-2 last:border-b-0">
                <span className="text-gray-400">{item.metric}</span>
                <span className="font-mono font-semibold text-gray-200">{item.value}</span>
            </div>
        ))}
    </div>
);

const PeerComparisonTable: React.FC<{ metrics: PeerMetric[] }> = ({ metrics }) => (
    <table className="w-full text-left text-sm">
        <thead>
            <tr className="border-b border-gray-600">
                <th className="py-2 font-medium text-gray-400">Metric</th>
                <th className="py-2 font-medium text-gray-400 text-right">Company</th>
                <th className="py-2 font-medium text-gray-400 text-right">{metrics[0]?.peerName || 'Peer'}</th>
            </tr>
        </thead>
        <tbody>
            {metrics.map((item, index) => (
                <tr key={index} className="border-b border-gray-700/50 last:border-b-0">
                    <td className="py-2 font-semibold text-gray-200">{item.metric}</td>
                    <td className="py-2 font-mono text-gray-200 text-right">{item.companyValue}</td>
                    <td className="py-2 font-mono text-gray-400 text-right">{item.peerValue}</td>
                </tr>
            ))}
        </tbody>
    </table>
);

const SegmentPerformanceDisplay: React.FC<{ segments: SegmentPerformance[] }> = ({ segments }) => (
    <div className="space-y-4">
        {segments.map((item, index) => (
            <div key={index} className="bg-gray-800/70 p-4 rounded-md border border-gray-700">
                <h4 className="font-semibold text-gray-200">{item.segmentName}</h4>
                <p className="text-sm text-gray-400 mt-1 mb-2">{item.commentary}</p>
                <div className="text-right text-sm">
                    <span className="text-gray-500">Revenue: </span>
                    <span className="font-mono font-semibold text-cyan-400">{item.revenue}</span>
                </div>
            </div>
        ))}
    </div>
);


export const QuarterlyComparisonDisplay: React.FC<QuarterlyComparisonDisplayProps> = ({ analysis, sources, onReset }) => {
  return (
    <div className="max-w-5xl mx-auto animate-fade-in">
      <button onClick={onReset} className="mb-8 inline-flex items-center text-sm font-medium text-cyan-400 hover:text-cyan-300 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Analyze Something Else
      </button>

      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-white text-center">
            Quarterly Performance: <span className="text-cyan-400">{analysis.companyName}</span>
        </h2>
        
        <InfoCard title="Performance Summary">
            <p>{analysis.performanceSummary}</p>
        </InfoCard>

        <InfoCard title="Year-over-Year Key Metrics">
            <ComparisonTable 
                metrics={analysis.comparisonMetrics} 
                currentPeriod={analysis.currentPeriod}
                previousPeriod={analysis.previousPeriod}
            />
        </InfoCard>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <InfoCard title="Financial Health & Key Ratios">
                <p className="text-sm text-gray-400 mb-4">{analysis.balanceSheetHealth.summary}</p>
                <SimpleMetricsDisplay metrics={analysis.balanceSheetHealth.metrics} />
            </InfoCard>

            <InfoCard title="Management Guidance & Outlook">
                <p className="text-sm">{analysis.managementGuidance}</p>
            </InfoCard>
        </div>
        
        {analysis.segmentPerformance && analysis.segmentPerformance.length > 0 && (
            <InfoCard title="Segment Performance">
                <SegmentPerformanceDisplay segments={analysis.segmentPerformance} />
            </InfoCard>
        )}

        {analysis.risksAndOutlook && (
            <InfoCard title="Key Risks & Outlook">
                <p className="text-sm">{analysis.risksAndOutlook}</p>
            </InfoCard>
        )}

        {analysis.peerComparison && (
            <InfoCard title={`Peer Comparison vs. ${analysis.peerComparison.metrics[0]?.peerName || 'Competitor'}`}>
                <p className="text-sm text-gray-400 mb-4">{analysis.peerComparison.summary}</p>
                <PeerComparisonTable metrics={analysis.peerComparison.metrics} />
            </InfoCard>
        )}

        {sources && sources.length > 0 && (
          <InfoCard title="Grounding Sources (from AI Search)">
              <ul className="list-disc list-inside text-gray-400 text-sm space-y-2">
              {sources.map((source, index) => (
                  source.web?.uri && (
                  <li key={index}>
                      <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-cyan-500 hover:underline hover:text-cyan-400 transition-colors">
                      {source.web.title || source.web.uri}
                      </a>
                  </li>
                  )
              ))}
              </ul>
          </InfoCard>
        )}
      </div>
    </div>
  );
};