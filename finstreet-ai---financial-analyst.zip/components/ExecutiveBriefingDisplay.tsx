import React from 'react';
import type { ExecutiveBriefing, KeyMetric, Source } from '../types';

interface ExecutiveBriefingDisplayProps {
  briefing: ExecutiveBriefing;
  sources: Source[];
  onReset: () => void;
}

const InfoCard: React.FC<{ title: string; children: React.ReactNode, className?: string }> = ({ title, children, className = '' }) => (
  <div className={`bg-gray-800/50 border border-gray-700/60 rounded-lg shadow-lg p-6 ${className}`}>
    <h3 className="text-sm font-semibold text-cyan-400 uppercase tracking-wider mb-3">{title}</h3>
    <div className="text-gray-300 space-y-3 leading-relaxed">{children}</div>
  </div>
);

const OutcomePill: React.FC<{ outcome: KeyMetric['outcome'] }> = ({ outcome }) => {
  const baseClasses = "px-2.5 py-0.5 text-xs font-semibold rounded-full";
  let colorClasses = "bg-gray-700 text-gray-300";
  if (outcome === 'Beat') colorClasses = "bg-green-800/60 text-green-300";
  else if (outcome === 'Miss') colorClasses = "bg-red-800/60 text-red-300";
  else if (outcome === 'Met') colorClasses = "bg-blue-800/60 text-blue-300";
  
  return <span className={`${baseClasses} ${colorClasses}`}>{outcome}</span>;
}

const MetricsTable: React.FC<{ metrics: KeyMetric[] }> = ({ metrics }) => (
  <table className="w-full text-left">
    <thead>
      <tr className="border-b border-gray-600">
        <th className="py-2 text-xs font-medium text-gray-400">Metric</th>
        <th className="py-2 text-xs font-medium text-gray-400 text-right">Actual</th>
        <th className="py-2 text-xs font-medium text-gray-400 text-right">Consensus</th>
        <th className="py-2 pl-4 text-xs font-medium text-gray-400 text-right">Outcome</th>
      </tr>
    </thead>
    <tbody>
      {metrics.map((item, index) => (
        <tr key={index} className="border-b border-gray-700/50">
          <td className="py-3 font-semibold text-gray-200">{item.metric}</td>
          <td className="py-3 font-mono text-gray-200 text-right">{item.value}</td>
          <td className="py-3 font-mono text-gray-400 text-right">{item.consensus}</td>
          <td className="py-3 text-right pl-4"><OutcomePill outcome={item.outcome} /></td>
        </tr>
      ))}
    </tbody>
  </table>
);

export const ExecutiveBriefingDisplay: React.FC<ExecutiveBriefingDisplayProps> = ({ briefing, sources, onReset }) => {
  return (
    <div className="max-w-7xl mx-auto animate-fade-in">
      <button onClick={onReset} className="mb-8 inline-flex items-center text-sm font-medium text-cyan-400 hover:text-cyan-300 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Analyze Another Document or Article
      </button>

      <div className="space-y-6">
        <InfoCard title="Executive Summary">
            <p>{briefing.summary}</p>
        </InfoCard>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            <div className="lg:col-span-3">
                 <InfoCard title="Key Financial Metrics">
                    <MetricsTable metrics={briefing.keyMetrics} />
                </InfoCard>
            </div>
            <div className="lg:col-span-2">
                 <InfoCard title="Management Sentiment">
                   <div className="flex items-center mb-4">
                       <span className="text-gray-400 mr-2">Tone:</span>
                       <span className="px-3 py-1 text-sm font-semibold text-yellow-300 bg-yellow-800/50 rounded-full">{briefing.managementSentiment.tone}</span>
                   </div>
                   <blockquote className="space-y-3">
                       {briefing.managementSentiment.keyQuotes.map((quote, i) => (
                           <p key={i} className="border-l-4 border-cyan-500 pl-4 text-gray-400 italic">"{quote}"</p>
                       ))}
                   </blockquote>
                </InfoCard>
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <InfoCard title="Forward-Looking Guidance">
                <p>{briefing.forwardLookingGuidance}</p>
            </InfoCard>
            <InfoCard title="Analyst Q&A Summary">
                <p>{briefing.analystQuestionsSummary}</p>
            </InfoCard>
        </div>
        
        <InfoCard title="Strategic Themes">
          <div className="flex flex-wrap gap-2">
            {briefing.strategicThemes.map((tag, index) => (
                <span key={index} className="px-3 py-1 text-xs font-medium text-teal-300 bg-teal-800/50 rounded-full">{tag}</span>
            ))}
          </div>
        </InfoCard>

        {sources && sources.length > 0 && (
          <InfoCard title="Grounding Sources (from AI Search)">
              <ul className="list-disc list-inside text-gray-400 text-sm space-y-2">
              {sources.map((source, index) => (
                  source.web?.uri && (
                  <li key={index}>
                      <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-cyan-500 hover:underline hover:text-cyan-400 transition-colors">
                      {source.web.title || source.web.uri}
                      </a>
                  </li>
                  )
              ))}
              </ul>
          </InfoCard>
        )}
      </div>
    </div>
  );
};
