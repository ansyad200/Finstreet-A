import React from 'react';
import type { NewsAnalysis, Source } from '../types';

interface NewsAnalysisDisplayProps {
  analysis: NewsAnalysis;
  sources: Source[];
  onReset: () => void;
}

const InfoCard: React.FC<{ title: string; children: React.ReactNode, className?: string }> = ({ title, children, className = '' }) => (
  <div className={`bg-gray-800/50 border border-gray-700/60 rounded-lg shadow-lg p-6 ${className}`}>
    <h3 className="text-sm font-semibold text-cyan-400 uppercase tracking-wider mb-3">{title}</h3>
    <div className="text-gray-300 space-y-3 leading-relaxed">{children}</div>
  </div>
);

const SentimentPill: React.FC<{ sentiment: NewsAnalysis['sentiment'] }> = ({ sentiment }) => {
  const baseClasses = "px-3 py-1 text-sm font-semibold rounded-full";
  let colorClasses = "bg-gray-700 text-gray-300";
  if (sentiment === 'Positive') colorClasses = "bg-green-800/60 text-green-300";
  else if (sentiment === 'Negative') colorClasses = "bg-red-800/60 text-red-300";
  
  return <span className={`${baseClasses} ${colorClasses}`}>{sentiment}</span>;
}

const ImpactPill: React.FC<{ impact: NewsAnalysis['predictedImpact'] }> = ({ impact }) => {
    const baseClasses = "px-3 py-1 text-sm font-semibold rounded-full";
    let colorClasses = "bg-gray-700 text-gray-300";
    if (impact === 'High') colorClasses = "bg-red-800/60 text-red-300";
    else if (impact === 'Medium') colorClasses = "bg-yellow-800/60 text-yellow-300";
    else if (impact === 'Low') colorClasses = "bg-blue-800/60 text-blue-300";
    
    return <span className={`${baseClasses} ${colorClasses}`}>{impact}</span>;
  }

export const NewsAnalysisDisplay: React.FC<NewsAnalysisDisplayProps> = ({ analysis, sources, onReset }) => {
  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
      <button onClick={onReset} className="mb-8 inline-flex items-center text-sm font-medium text-cyan-400 hover:text-cyan-300 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Analyze Something Else
      </button>

      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <InfoCard title="Sentiment" className="flex flex-col items-center justify-center text-center">
                <SentimentPill sentiment={analysis.sentiment} />
            </InfoCard>
            <InfoCard title="Predicted Impact" className="flex flex-col items-center justify-center text-center">
                <ImpactPill impact={analysis.predictedImpact} />
            </InfoCard>
             <InfoCard title="Confidence" className="flex flex-col items-center justify-center text-center">
                <div className="text-2xl font-bold text-white">
                    {(analysis.confidenceScore * 100).toFixed(0)}%
                </div>
            </InfoCard>
        </div>

        <InfoCard title="Rationale">
            <p>{analysis.rationale}</p>
        </InfoCard>
        
        {sources && sources.length > 0 && (
          <InfoCard title="Grounding Sources (from AI Search)">
              <ul className="list-disc list-inside text-gray-400 text-sm space-y-2">
              {sources.map((source, index) => (
                  source.web?.uri && (
                  <li key={index}>
                      <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-cyan-500 hover:underline hover:text-cyan-400 transition-colors">
                      {source.web.title || source.web.uri}
                      </a>
                  </li>
                  )
              ))}
              </ul>
          </InfoCard>
        )}
      </div>
    </div>
  );
};
