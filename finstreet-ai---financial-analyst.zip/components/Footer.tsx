import React from 'react';

export const Footer = () => {
  return (
    <footer className="bg-gray-900/50 border-t border-gray-800/50 mt-12">
      <div className="container mx-auto px-4 py-6 text-center text-gray-500 text-xs">
        <p className="font-bold text-red-400/80 mb-2">Disclaimer: Not Financial Advice</p>
        <p className="mb-2">Finstreet AI is an experimental tool using AI for informational and educational purposes only. The analysis provided, whether for news or financial documents, is not a guarantee of future results and should not be considered investment advice. Always conduct your own research and consult with a qualified financial professional before making any investment decisions.</p>
        <p>&copy; {new Date().getFullYear()} Finstreet AI. All rights reserved.</p>
      </div>
    </footer>
  );
};