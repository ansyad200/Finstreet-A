import React, { useState, useEffect } from 'react';
import { NewsCard } from './NewsCard';
import type { NewsArticle } from '../types';
import { fetchTopHeadlines } from '../services/newsApiService';

interface NewsFeedProps {
    onAnalyze: (text: string) => void;
    onBack: () => void;
    isAnalyzing: boolean;
}

export const NewsFeed: React.FC<NewsFeedProps> = ({ onAnalyze, onBack, isAnalyzing }) => {
    const [articles, setArticles] = useState<NewsArticle[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [customText, setCustomText] = useState<string>('');

    useEffect(() => {
        const loadHeadlines = async () => {
            setIsLoading(true);
            setError(null);
            try {
                const fetchedArticles = await fetchTopHeadlines();
                if (fetchedArticles.length === 0) {
                    setError('Could not fetch top headlines. The news service might be temporarily unavailable. You can still paste your own article below.');
                }
                setArticles(fetchedArticles);
            } catch (e) {
                const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred';
                setError(`Failed to load news: ${errorMessage}`);
            } finally {
                setIsLoading(false);
            }
        };
        loadHeadlines();
    }, []);

    const handleArticleAnalyze = (article: NewsArticle) => {
        const contentToAnalyze = article.content || article.description || article.title;
        onAnalyze(contentToAnalyze);
    };

    const handleCustomAnalyze = () => {
        if (customText.trim()) {
            onAnalyze(customText);
        }
    };

    return (
        <div className="max-w-7xl w-full mx-auto animate-fade-in">
             <button onClick={onBack} className="mb-8 inline-flex items-center text-sm font-medium text-cyan-400 hover:text-cyan-300 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
                Back to Selector
            </button>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="lg:col-span-2">
                     <h2 className="text-2xl font-bold text-white mb-2">Analyze Custom Article</h2>
                     <p className="text-sm text-gray-400 mb-4">Paste the full text of a news article below to get an instant analysis.</p>
                     <div className="bg-gray-800/50 border border-gray-700/80 rounded-lg p-4">
                         <textarea
                            value={customText}
                            onChange={(e) => setCustomText(e.target.value)}
                            placeholder="Paste your news article text here..."
                            className="w-full h-40 bg-gray-900 border border-gray-600 rounded-md p-3 text-gray-300 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-colors"
                            disabled={isAnalyzing}
                        />
                        <button
                            onClick={handleCustomAnalyze}
                            disabled={isAnalyzing || !customText.trim()}
                            className="mt-3 w-full sm:w-auto float-right px-6 py-2 font-semibold text-white bg-cyan-600 rounded-md hover:bg-cyan-700 focus:ring-4 focus:ring-cyan-500/50 focus:outline-none disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors"
                        >
                            {isAnalyzing ? 'Analyzing...' : 'Analyze Custom Text'}
                        </button>
                     </div>
                </div>

                <div className="lg:col-span-2">
                     <h2 className="text-2xl font-bold text-white mb-4">Or Analyze Top Business Headlines</h2>
                     {isLoading && <p className="text-gray-400">Loading top headlines...</p>}
                     {error && <p className="text-red-400">{error}</p>}
                     {!isLoading && articles.length > 0 && (
                         <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                            {articles.map((article, index) => (
                                <NewsCard key={`${article.url}-${index}`} article={article} onAnalyze={handleArticleAnalyze} isAnalyzing={isAnalyzing} />
                            ))}
                         </div>
                     )}
                </div>
            </div>
        </div>
    );
};
