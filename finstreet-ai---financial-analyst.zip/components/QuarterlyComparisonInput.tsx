import React, { useState } from 'react';
import { indianStocks } from '../data/indianStocks';

interface QuarterlyComparisonInputProps {
    onAnalyze: (company: string, year: string, quarter: string) => void;
    onBack: () => void;
    isAnalyzing: boolean;
}

const QuarterlyComparisonIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
    </svg>
);

export const QuarterlyComparisonInput: React.FC<QuarterlyComparisonInputProps> = ({ onAnalyze, onBack, isAnalyzing }) => {
    const [company, setCompany] = useState('');
    const [year, setYear] = useState(new Date().getFullYear().toString());
    const [quarter, setQuarter] = useState('Q2');
    const [error, setError] = useState('');
    
    const [suggestions, setSuggestions] = useState<{name: string, symbol: string}[]>([]);
    const [isSuggestionsVisible, setIsSuggestionsVisible] = useState(false);

    const handleCompanyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setCompany(value);

        if (value.length > 1) {
            const filteredSuggestions = indianStocks.filter(stock => 
                stock.name.toLowerCase().includes(value.toLowerCase()) || 
                stock.symbol.toLowerCase().includes(value.toLowerCase())
            );
            setSuggestions(filteredSuggestions.slice(0, 10)); // Limit to 10 suggestions for performance
            setIsSuggestionsVisible(true);
        } else {
            setSuggestions([]);
            setIsSuggestionsVisible(false);
        }
    };
    
    const handleSuggestionClick = (stockName: string) => {
        setCompany(stockName);
        setSuggestions([]);
        setIsSuggestionsVisible(false);
    };

    const handleSubmit = () => {
        if (!company.trim()) {
            setError('Please enter a company name or stock ticker.');
            return;
        }
        if (!year.trim() || isNaN(parseInt(year, 10)) || year.length !== 4) {
            setError('Please enter a valid 4-digit year.');
            return;
        }
        setError('');
        onAnalyze(company, year, quarter);
    };

    return (
        <div className="max-w-2xl mx-auto w-full animate-fade-in">
             <button onClick={onBack} className="mb-8 inline-flex items-center text-sm font-medium text-cyan-400 hover:text-cyan-300 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
                Back to Selector
            </button>
            <div className="bg-gray-800/50 border border-gray-700/80 rounded-lg shadow-lg p-8">
                <div className="text-center mb-6">
                    <div className="flex justify-center mb-4">
                        <QuarterlyComparisonIcon />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-100">Quarterly Performance Comparison</h2>
                    <p className="text-sm text-gray-400 mt-2">Analyze a company's year-over-year quarterly results.</p>
                </div>

                <div className="space-y-6">
                    <div className="relative">
                        <label htmlFor="company-name" className="block text-sm font-medium text-gray-300 mb-2">Company Name or Ticker</label>
                        <input
                            type="text"
                            id="company-name"
                            value={company}
                            onChange={handleCompanyChange}
                            onFocus={() => { if (company.length > 1 && suggestions.length > 0) setIsSuggestionsVisible(true); }}
                            onBlur={() => setTimeout(() => setIsSuggestionsVisible(false), 200)}
                            placeholder="e.g., Reliance or INFY"
                            className="w-full bg-gray-900 border border-gray-600 rounded-md p-3 text-gray-300 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-colors"
                            disabled={isAnalyzing}
                            autoComplete="off"
                        />
                        {isSuggestionsVisible && suggestions.length > 0 && (
                            <ul className="absolute z-10 w-full bg-gray-700 border border-gray-600 rounded-md mt-1 max-h-60 overflow-y-auto shadow-lg">
                                {suggestions.map((stock) => (
                                    <li 
                                        key={stock.symbol}
                                        onMouseDown={() => handleSuggestionClick(stock.name)}
                                        className="px-4 py-2 text-gray-200 cursor-pointer hover:bg-cyan-600 transition-colors"
                                    >
                                        <span className="font-semibold">{stock.name}</span>
                                        <span className="text-gray-400 ml-2">({stock.symbol})</span>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                         <div>
                            <label htmlFor="year" className="block text-sm font-medium text-gray-300 mb-2">Year</label>
                            <input
                                type="number"
                                id="year"
                                value={year}
                                onChange={(e) => setYear(e.target.value)}
                                placeholder="e.g., 2024"
                                className="w-full bg-gray-900 border border-gray-600 rounded-md p-3 text-gray-300 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-colors"
                                disabled={isAnalyzing}
                            />
                        </div>
                        <div>
                            <label htmlFor="quarter" className="block text-sm font-medium text-gray-300 mb-2">Quarter</label>
                            <select
                                id="quarter"
                                value={quarter}
                                onChange={(e) => setQuarter(e.target.value)}
                                className="w-full bg-gray-900 border border-gray-600 rounded-md p-3 text-gray-300 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-colors"
                                disabled={isAnalyzing}
                            >
                                <option>Q1</option>
                                <option>Q2</option>
                                <option>Q3</option>
                                <option>Q4</option>
                            </select>
                        </div>
                    </div>
                     {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                    <button
                        onClick={handleSubmit}
                        disabled={isAnalyzing || !company.trim()}
                        className="w-full px-6 py-3 font-semibold text-white bg-cyan-600 rounded-md hover:bg-cyan-700 focus:ring-4 focus:ring-cyan-500/50 focus:outline-none disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors"
                    >
                        {isAnalyzing ? 'Analyzing...' : 'Get YoY Comparison'}
                    </button>
                </div>
            </div>
        </div>
    );
};