import React from 'react';

interface SpinnerProps {
    message?: string;
}

const TrendlineSpinner: React.FC = () => (
    <svg viewBox="0 0 150 60" className="w-64 h-auto" aria-hidden="true">
        {/* Red downward trend line */}
        <path 
            d="M 75 30 L 60 45 L 45 25 L 30 50 L 15 40 L 0 55" 
            stroke="#ef4444" // Tailwind red-500
            strokeWidth="2.5" 
            fill="none" 
            strokeLinecap="round" 
            strokeLinejoin="round"
            className="animate-draw-line"
        />
        {/* Green upward trend line */}
        <path 
            d="M 75 30 L 90 15 L 105 35 L 120 10 L 135 20 L 150 5" 
            stroke="#22c55e" // Tailwind green-500
            strokeWidth="2.5" 
            fill="none" 
            strokeLinecap="round" 
            strokeLinejoin="round"
            className="animate-draw-line"
        />
        {/* Central pulsing "processing" dot */}
        <circle cx="75" cy="30" r="4" fill="#38bdf8" // Tailwind cyan-400
            className="animate-pulse-dot"
        />
    </svg>
);


export const Spinner: React.FC<SpinnerProps> = ({ message }) => {
    return (
        <div className="flex flex-col items-center justify-center text-center animate-fade-in p-8">
            <div className="relative mb-6">
                <TrendlineSpinner />
            </div>
            <h2 className="text-xl font-bold text-gray-100">{message || 'Analyzing...'}</h2>
            <p className="text-sm text-gray-400 mt-2">This may take a moment...</p>
        </div>
    );
};