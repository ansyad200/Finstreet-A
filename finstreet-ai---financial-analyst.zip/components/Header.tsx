import React from 'react';

const ChartBarIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 mr-2 text-cyan-400">
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18 9 11.25l4.306 4.306a11.95 11.95 0 0 1 5.814-5.518l2.74-1.22m0 0-5.94-2.281m5.94 2.28-2.28 5.941" />
  </svg>
);


export const Header: React.FC = () => {
  return (
    <header className="bg-gray-900/70 backdrop-blur-sm border-b border-gray-800/50 sticky top-0 z-30">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <ChartBarIcon />
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Finstreet<span className="text-cyan-400">AI</span>
          </h1>
        </div>
        <div className="text-sm text-gray-400 hidden sm:block">
          AI Financial Analyst
        </div>
      </div>
    </header>
  );
};