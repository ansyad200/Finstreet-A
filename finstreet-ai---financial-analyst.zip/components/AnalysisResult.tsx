import React from 'react';
import type { QuarterlyComparison, QuarterlyComparisonMetric, Source } from '../types';

interface QuarterlyComparisonDisplayProps {
  analysis: QuarterlyComparison;
  sources: Source[];
  onReset: () => void;
}

const InfoCard: React.FC<{ title: string; children: React.ReactNode, className?: string }> = ({ title, children, className = '' }) => (
  <div className={`bg-gray-800/50 border border-gray-700/60 rounded-lg shadow-lg p-6 ${className}`}>
    <h3 className="text-sm font-semibold text-cyan-400 uppercase tracking-wider mb-3">{title}</h3>
    <div className="text-gray-300 space-y-3 leading-relaxed">{children}</div>
  </div>
);

const ChangeIndicator: React.FC<{ value: number }> = ({ value }) => {
    const isPositive = value >= 0;
    const colorClass = isPositive ? 'text-green-400' : 'text-red-400';
    const icon = isPositive ? (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
        </svg>
    ) : (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
    );

    return (
        <span className={`flex items-center justify-end font-mono ${colorClass}`}>
            {icon}
            {value.toFixed(2)}%
        </span>
    );
};


const ComparisonTable: React.FC<{ metrics: QuarterlyComparisonMetric[], currentPeriod: string, previousPeriod: string }> = ({ metrics, currentPeriod, previousPeriod }) => (
  <table className="w-full text-left">
    <thead>
      <tr className="border-b border-gray-600">
        <th className="py-2 text-xs font-medium text-gray-400">Metric</th>
        <th className="py-2 text-xs font-medium text-gray-400 text-right">{currentPeriod}</th>
        <th className="py-2 text-xs font-medium text-gray-400 text-right">{previousPeriod}</th>
        <th className="py-2 pl-4 text-xs font-medium text-gray-400 text-right">YoY Change</th>
      </tr>
    </thead>
    <tbody>
      {metrics.map((item, index) => (
        <tr key={index} className="border-b border-gray-700/50">
          <td className="py-3 font-semibold text-gray-200">{item.metric}</td>
          <td className="py-3 font-mono text-gray-200 text-right">{item.currentValue}</td>
          <td className="py-3 font-mono text-gray-400 text-right">{item.previousValue}</td>
          <td className="py-3 text-right pl-4">
            <ChangeIndicator value={item.changePercentage} />
          </td>
        </tr>
      ))}
    </tbody>
  </table>
);

export const QuarterlyComparisonDisplay: React.FC<QuarterlyComparisonDisplayProps> = ({ analysis, sources, onReset }) => {
  return (
    <div className="max-w-5xl mx-auto animate-fade-in">
      <button onClick={onReset} className="mb-8 inline-flex items-center text-sm font-medium text-cyan-400 hover:text-cyan-300 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Analyze Something Else
      </button>

      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-white text-center">
            Quarterly Performance: <span className="text-cyan-400">{analysis.companyName}</span>
        </h2>
        
        <InfoCard title="Performance Summary">
            <p>{analysis.performanceSummary}</p>
        </InfoCard>

        <InfoCard title="Year-over-Year Comparison">
            <ComparisonTable 
                metrics={analysis.comparisonMetrics} 
                currentPeriod={analysis.currentPeriod}
                previousPeriod={analysis.previousPeriod}
            />
        </InfoCard>

        {sources && sources.length > 0 && (
          <InfoCard title="Grounding Sources (from AI Search)">
              <ul className="list-disc list-inside text-gray-400 text-sm space-y-2">
              {sources.map((source, index) => (
                  source.web?.uri && (
                  <li key={index}>
                      <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-cyan-500 hover:underline hover:text-cyan-400 transition-colors">
                      {source.web.title || source.web.uri}
                      </a>
                  </li>
                  )
              ))}
              </ul>
          </InfoCard>
        )}
      </div>
    </div>
  );
};
