import React from 'react';
import type { NewsArticle } from '../types';

interface NewsCardProps {
  article: NewsArticle;
  onAnalyze: (article: NewsArticle) => void;
  isAnalyzing: boolean;
}

const NewsSourceIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
        <path d="M2 5a2 2 0 012-2h12a2 2 0 012 2v10a2 2 0 01-2 2H4a2 2 0 01-2-2V5zm3.293 1.293a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 01-1.414-1.414L7.586 10 5.293 7.707a1 1 0 010-1.414zM11 12a1 1 0 100 2h3a1 1 0 100-2h-3z" />
    </svg>
);


export const NewsCard: React.FC<NewsCardProps> = ({ article, onAnalyze, isAnalyzing }) => {
  return (
    <div className="bg-gray-800/50 border border-gray-700/80 rounded-lg shadow-lg p-5 flex flex-col justify-between transition-all duration-300 hover:border-cyan-500/50 hover:bg-gray-800">
      <div>
        <h3 className="font-bold text-md text-gray-100 mb-2 leading-snug">{article.title}</h3>
        <div className="flex items-center text-xs text-gray-400 mb-4">
            <NewsSourceIcon />
            <span>{article.source.name}</span>
        </div>
      </div>
      <button
        onClick={() => onAnalyze(article)}
        disabled={isAnalyzing}
        className="self-start mt-2 px-4 py-2 text-xs font-semibold text-white bg-cyan-600 rounded-md hover:bg-cyan-700 focus:ring-4 focus:ring-cyan-500/50 focus:outline-none disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors"
      >
        Analyze
      </button>
    </div>
  );
};