import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { Spinner } from './components/Spinner';
import { Footer } from './components/Footer';
import { analyzeFinancialNews, analyzeQuarterlyPerformance } from './services/geminiService';
import type { NewsAnalysis, Source, QuarterlyComparison } from './types';
import { NewsAnalysisDisplay } from './components/NewsAnalysisDisplay';
import { NewsFeed } from './components/NewsFeed';
import { QuarterlyComparisonInput } from './components/QuarterlyComparisonInput';
import { QuarterlyComparisonDisplay } from './components/QuarterlyComparisonDisplay';


type View = 'selector' | 'news_input' | 'quarterly_comparison_input' | 'analyzing' | 'result' | 'error';
type AnalysisType = 'news' | 'quarterly' | null;

type ResultData = {
    news?: NewsAnalysis;
    quarterly?: QuarterlyComparison;
};

const NewsIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1">
        <path strokeLinecap="round" strokeLinejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m-1 13V10a2 2 0 00-2-2H7a2 2 0 00-2 2v10m13-10l-3-3m0 0l-3 3m3-3v12" />
    </svg>
);

const QuarterlyIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
    </svg>
);


const App: React.FC = () => {
    const [view, setView] = useState<View>('selector');
    const [analysisType, setAnalysisType] = useState<AnalysisType>(null);
    const [resultData, setResultData] = useState<ResultData | null>(null);
    const [sources, setSources] = useState<Source[]>([]);
    const [error, setError] = useState<string | null>(null);
    const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);

    const handleReset = useCallback(() => {
        setView('selector');
        setAnalysisType(null);
        setResultData(null);
        setSources([]);
        setError(null);
        setIsAnalyzing(false);
    }, []);

    const handleAnalyzeNews = useCallback(async (text: string) => {
        if (isAnalyzing) return;
        setIsAnalyzing(true);
        setAnalysisType('news');
        setView('analyzing');
        setError(null);

        try {
            const { result, sources } = await analyzeFinancialNews(text);
            setResultData({ news: result });
            setSources(sources);
            setView('result');
        } catch (e) {
            const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
            setError(`Failed to analyze news: ${errorMessage}`);
            setView('error');
        } finally {
            setIsAnalyzing(false);
        }
    }, [isAnalyzing]);
    
    const handleAnalyzeQuarterlyPerformance = useCallback(async (company: string, year: string, quarter: string) => {
        if (isAnalyzing) return;
        setIsAnalyzing(true);
        setAnalysisType('quarterly');
        setView('analyzing');
        setError(null);

        try {
            const { result, sources } = await analyzeQuarterlyPerformance(company, year, quarter);
            setResultData({ quarterly: result });
            setSources(sources);
            setView('result');
        } catch (e) {
            const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
            setError(`Failed to analyze quarterly performance: ${errorMessage}`);
            setView('error');
        } finally {
            setIsAnalyzing(false);
        }
    }, [isAnalyzing]);
    
    const renderContent = () => {
        switch (view) {
            case 'selector':
                return (
                    <div className="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fade-in">
                        <button onClick={() => setView('news_input')} className="text-center bg-gray-800/50 border border-gray-700/80 rounded-lg shadow-lg p-10 flex flex-col items-center justify-center transition-all duration-300 hover:border-cyan-500/50 hover:bg-gray-800 focus:outline-none focus:ring-4 focus:ring-cyan-500/30">
                            <NewsIcon />
                            <h2 className="text-xl font-bold text-gray-100">Analyze News Article</h2>
                            <p className="text-sm text-gray-400 mt-2">Get insights on breaking news from a live feed or your own text.</p>
                        </button>
                         <button onClick={() => setView('quarterly_comparison_input')} className="text-center bg-gray-800/50 border border-gray-700/80 rounded-lg shadow-lg p-10 flex flex-col items-center justify-center transition-all duration-300 hover:border-cyan-500/50 hover:bg-gray-800 focus:outline-none focus:ring-4 focus:ring-cyan-500/30">
                            <QuarterlyIcon />
                            <h2 className="text-xl font-bold text-gray-100 mt-4">Quarterly Performance</h2>
                            <p className="text-sm text-gray-400 mt-2">Compare a company's year-over-year quarterly results.</p>
                        </button>
                    </div>
                );

            case 'news_input':
                return <NewsFeed onAnalyze={handleAnalyzeNews} onBack={handleReset} isAnalyzing={isAnalyzing} />;
            
            case 'quarterly_comparison_input':
                return <QuarterlyComparisonInput onAnalyze={handleAnalyzeQuarterlyPerformance} onBack={handleReset} isAnalyzing={isAnalyzing} />;

            case 'analyzing':
                 const message = analysisType === 'quarterly'
                    ? 'Analyzing Quarterly Performance...'
                    : 'Analyzing Financial News...';
                 return <Spinner message={message} />;

            case 'result':
                if (analysisType === 'news' && resultData?.news) {
                    return <NewsAnalysisDisplay analysis={resultData.news} sources={sources} onReset={handleReset} />;
                }
                if (analysisType === 'quarterly' && resultData?.quarterly) {
                    return <QuarterlyComparisonDisplay analysis={resultData.quarterly} sources={sources} onReset={handleReset} />;
                }
                // Fallback if data is missing
                setError("An unexpected error occurred while displaying the results.");
                setView('error');
                return null;

            case 'error':
                return (
                    <div className="max-w-2xl mx-auto text-center animate-fade-in">
                        <div className="bg-red-900/40 border border-red-700 rounded-lg p-6">
                            <h2 className="text-xl font-bold text-red-300">Analysis Failed</h2>
                            <p className="text-red-400/80 mt-2">{error}</p>
                            <button onClick={handleReset} className="mt-6 px-5 py-2 text-sm font-semibold text-white bg-cyan-600 rounded-md hover:bg-cyan-700 focus:outline-none focus:ring-4 focus:ring-cyan-500/50">
                                Try Again
                            </button>
                        </div>
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className="min-h-screen bg-gray-900 text-gray-200 flex flex-col">
            <Header />
            <main className="flex-grow container mx-auto p-4 sm:p-6 md:p-8 flex items-center justify-center">
                {renderContent()}
            </main>
            <Footer />
        </div>
    );
};

export default App;