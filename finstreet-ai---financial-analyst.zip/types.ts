export interface NewsAnalysis {
    sentiment: 'Positive' | 'Negative' | 'Neutral';
    predictedImpact: 'High' | 'Medium' | 'Low' | 'N/A';
    rationale: string;
    confidenceScore: number;
}

export interface Source {
  web?: {
    uri?: string;
    title?: string;
  };
}

export interface NewsArticle {
  title: string;
  description: string | null;
  content: string | null;
  url: string;
  source: {
    id: string | null;
    name: string;
  };
}

export interface VerificationData {
  credibility: 'High' | 'Medium' | 'Low';
  verifiedSources: string[];
}

export interface KeyMetric {
    metric: string;
    value: string;
    consensus: string;
    outcome: 'Beat' | 'Miss' | 'Met';
}

export interface ExecutiveBriefing {
    summary: string;
    keyMetrics: KeyMetric[];
    managementSentiment: {
        tone: string;
        keyQuotes: string[];
    };
    forwardLookingGuidance: string;
    analystQuestionsSummary: string;
    strategicThemes: string[];
}

export interface QuarterlyComparisonMetric {
    metric: string;
    currentValue: string;
    previousValue: string;
    changePercentage: number | null;
}

export interface SimpleKeyValueMetric {
    metric: string;
    value: string;
}

export interface PeerMetric {
    metric: string;
    companyValue: string;
    peerName: string;
    peerValue: string;
}

export interface SegmentPerformance {
    segmentName: string;
    revenue: string;
    commentary: string;
}

export interface QuarterlyComparison {
    companyName: string;
    currentPeriod: string; // "Q2 2024"
    previousPeriod: string; // "Q2 2023"
    performanceSummary: string;
    comparisonMetrics: QuarterlyComparisonMetric[];
    managementGuidance: string;
    balanceSheetHealth: {
        summary: string;
        metrics: SimpleKeyValueMetric[];
    };
    segmentPerformance: SegmentPerformance[] | null;
    risksAndOutlook: string | null;
    peerComparison: {
        summary: string;
        metrics: PeerMetric[];
    } | null;
}
